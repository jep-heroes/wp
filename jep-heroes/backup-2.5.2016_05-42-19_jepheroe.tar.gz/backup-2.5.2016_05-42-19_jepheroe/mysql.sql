-- cPanel mysql backup
GRANT USAGE ON *.* TO 'jepheroe'@'localhost' IDENTIFIED BY PASSWORD '*4D2387E34A7B7CF37B4C715594C5CE5BB4A0F67F';
GRANT ALL PRIVILEGES ON `jepheroe\_wp`.* TO 'jepheroe'@'localhost';
GRANT ALL PRIVILEGES ON `jepheroe\_redmine`.* TO 'jepheroe'@'localhost';
GRANT USAGE ON *.* TO 'jepheroe_admin'@'localhost' IDENTIFIED BY PASSWORD '*A6FFD9159A5A6930786E79E4790CB407527E9142';
GRANT ALL PRIVILEGES ON `jepheroe\_wp`.* TO 'jepheroe_admin'@'localhost';
GRANT USAGE ON *.* TO 'jepheroe_redmine'@'localhost' IDENTIFIED BY PASSWORD '*3E96B092F44D6A0ACCC523BBEF0440E783EF2877';
GRANT ALL PRIVILEGES ON `jepheroe\_redmine`.* TO 'jepheroe_redmine'@'localhost';
