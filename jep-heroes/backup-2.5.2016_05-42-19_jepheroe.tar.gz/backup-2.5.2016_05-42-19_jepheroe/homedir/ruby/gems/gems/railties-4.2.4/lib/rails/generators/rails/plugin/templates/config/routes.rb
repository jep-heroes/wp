<% if mountable? -%>
<%= camelized %>::Engine.routes.draw do
<% else -%>
Rails.application.routes.draw do
<% end -%>
end
