require 'rails/generators/test_unit'

module TestUnit # :nodoc:
  module Generators # :nodoc:
    class HelperGenerator < Base # :nodoc:
      # Rails does not generate anything here.
    end
  end
end
