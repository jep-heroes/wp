module ProtectedAttributes
  VERSION = "1.1.3"
end
