require 'mkmf'

create_makefile 'json/ext/parser'
